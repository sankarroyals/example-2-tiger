import React, { Component } from 'react'

export default class Editprofile extends Component {
  render() {
    return (
      <div>
        
      </div>
    )
  }
}
